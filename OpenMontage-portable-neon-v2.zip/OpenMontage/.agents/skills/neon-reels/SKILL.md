---
name: neon-reels
description: Produksi Reels Indonesia dengan native neon 3D, narasi Piper lokal dan ekspor MP4 yang telah diperiksa.
---

1. Baca `AGENT_GUIDE.md`, `portable/CREATOR_PROFILE.md`, manifest `pipeline_defs/animated-explainer.yaml`, lalu director skill setiap tahap. Ini tidak menggantikan pipeline.
2. Periksa mesin: `bash portable/run.sh python portable/doctor.py`; untuk mesin baru jalankan `portable/smoke.py`. Semua CLI dijalankan dari root checkout yang sama.
3. Audit registry dengan `.venv/bin` pada PATH. Render memakai Remotion untuk native 3D. Ikuti aturan pemilihan runtime dan approval pengguna; jangan diam-diam mengganti runtime/provider.
4. Baca `.agents/skills/remotion-best-practices/SKILL.md`, `rules/3d.md`, `rules/animations.md`, `rules/audio.md`, `rules/subtitles.md`, serta skill atelier dan reviewer sebelum produksi. Knowledge vendor lengkap sudah berada di `.agents/skills/`; jangan mengunduh ulang skills dari sumber acak.
5. Bagi naskah menjadi hook terpisah, fakta-fakta dan CTA tanpa menambah/mengubah kata. Catat persetujuan, perkiraan biaya, jalur suara dan gaya yang benar-benar diminta.
6. Piper registry wrapper tersedia untuk sintesis biasa. Bila membutuhkan native phoneme alignment, gunakan helper SDK lokal `portable/tts.py` karena wrapper belum mengekspos alignment. Jalankan sekali per bagian: `bash portable/run.sh python portable/tts.py --text-file projects/<slug>/section.txt --out projects/<slug>/assets/audio/section.wav`. Rekam `source_tool=piper_tts`, model, settings, helper SDK dan biaya API nol dalam manifest. Jangan memasukkan tag `[piper]` ke teks yang dibacakan.
7. Helper menghasilkan WAV dan JSON word timestamps. Gunakan durasi riil dan timestamp itu untuk scene bounds/captions, dengan jeda nyaman antarbabak. Punctuation/token grouping yang gagal harus diperiksa; jangan mengarang timestamp. Buat master narasi dengan headroom dan musik/SFX pelan; gabungkan lewat Audio Remotion sesuai compose director.
8. Author scene baru sesuai topik. `portable/examples/calendar-neon/` adalah referensi mekanik/alur visual, bukan template kreatif untuk semua topik. Stage composition ke `remotion-composer/projects/<slug>/`. `ThreeCanvas`, material dan kamera semuanya mengikuti frame; CanvasTexture dibuat sinkron. Hindari permukaan coplanar, teks kecil tertutup, dan globe/peta geografis palsu.
9. Jalankan CompositionValidator sebelum render. Untuk browser lokal gunakan `REMOTION_BROWSER_EXECUTABLE` jika diperlukan; software WebGL `--gl=swangle` dan concurrency 2 untuk RAM terbatas, 4 untuk mesin yang memadai. Jangan mematikan TLS/proxy untuk download.
10. Review still per adegan, lalu render yang diizinkan. ffprobe/full decode dan review MP4 aktual wajib. Periksa 3 keadaan gerak per adegan, subtitle, semua bagian audio, waveform/master peak. ASR independen opsional bila tersedia; laporkan dengan jujur metode yang benar-benar dipakai. Serahkan MP4, bukan WAV terpisah.

Model disimpan di `.runtime/piper/`, tidak masuk Git. Lihat catatan lisensi model dalam guidebook sebelum penggunaan komersial. Jika skill native tidak terdeteksi oleh CLI, baca file ini secara eksplisit; instruksinya tetap dapat dijalankan tanpa integrasi khusus.
